import os
import re
import json
import pyodbc
import logging
from openai import OpenAI
from modules.db import get_db

log = logging.getLogger(__name__)

OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-5-mini")

# Vistas autorizadas. El asistente NO debe consultar tablas físicas.
TABLAS_PERMITIDAS = [
    "vw_om_reporte_base",
    "vw_om_acciones_base",
]

PROHIBIDAS = [
    "INSERT", "UPDATE", "DELETE", "DROP", "ALTER", "TRUNCATE",
    "MERGE", "EXEC", "CREATE", "GRANT", "REVOKE", "XP_",
    "INFORMATION_SCHEMA", "SYS.", "--", "/*", "*/"
]

PALABRAS_OM = [
    "om", "oms", "oportunidad", "oportunidades", "mejora", "reclamo", "reclamos",
    "cliente", "clientes", "proceso", "departamento", "sponsor", "responsable",
    "usuario", "creador", "jefe", "tipo", "estado", "abierta", "abiertas",
    "cerrada", "cerradas", "pendiente", "pendientes", "respuesta", "respuestas",
    "fecha", "fechas", "mes", "semana", "dia", "dias", "mayo", "promedio",
    "tiempo", "flujo", "trazabilidad", "linea", "historial", "equipo", "miembro",
    "accion", "acciones", "control", "correctiva", "correctivas", "cumplimiento",
    "vencida", "vencidas", "vencer", "vencen", "vencio", "vencieron", "evidencia"
]

PREGUNTAS_GUIA = """
Ejemplos de preguntas que el usuario puede hacer y que debes responder si hay columnas disponibles:

Volumen general:
- Cuántas OM hay en total.
- Cuántas OM hay abiertas.
- Cuántas OM hay cerradas.
- Cuántas OM se crearon hoy / esta semana / este mes.
- Cuántas OM cerradas hay por mes.
- Cuántas OM abiertas hay por mes.

Clientes:
- Cuántas OM hay por cliente.
- Qué cliente tiene más OM.
- Qué clientes tienen OM abiertas.
- Cuántas OM cerradas tiene cada cliente.
- Qué tipo de OM tiene cada cliente.
- Cuántas OM por tipo de reclamo y cliente.

Procesos/departamentos:
- Cuántas OM hay por proceso.
- Qué proceso tiene más OM.
- Qué procesos tienen más OM abiertas/cerradas/sin respuesta.
- Cuántas OM tiene Sistemas, Comercial, Quimitransport u otro proceso/departamento.
- Cuántas OM hay por proceso y mes.

Tipo de reclamo / tipo OM:
- Cuántas OM hay por tipo de reclamo.
- Cuál es el tipo de reclamo más frecuente.
- Cuántas OM por tipo de reclamo y cliente.
- Cuántas OM por tipo de reclamo y proceso.
- Cuántas OM por tipo de reclamo y sponsor.
- Cuántas OM por tipo de reclamo y mes.

Sponsors / responsables:
- Cuántas OM tiene cada sponsor.
- Qué sponsor tiene más OM asignadas.
- Qué sponsor tiene más OM cerradas/abiertas/sin respuesta.
- Cuántas OM tiene cada sponsor por mes.
- Promedio de días de respuesta por sponsor.
- Qué sponsor responde más rápido o más lento.

Usuarios / creadores:
- Cuántas OM creó cada usuario.
- Qué usuario creó más OM.
- Cuántas OM creó cada usuario por mes.
- Cuántas OM creó cada usuario en mayo.
- Frecuencia de creación de OM por usuario.

Fechas y tendencias:
- Cuántas OM se crearon por mes, semana o día.
- Cuántas OM se crearon cada día de mayo.
- Día con más creación de OM.
- Mes con más OM creadas.
- Frecuencia promedio de creación de OM por mes/semana.
- Cuántas OM se cerraron en los últimos 10 días.
- Cuántas OM se cerraron en los últimos 30 días.
- Cuántas OM se cerraron esta semana / ayer / hoy.

Tiempo de respuesta:
- Promedio de días de respuesta por sponsor, proceso, cliente, tipo de reclamo o usuario.
- OM con más días sin respuesta sponsor.
- OM con más de 5, 10 o 15 días sin respuesta.
- Tiempo de respuesta de la OM RECL00132.
- Cuántos días tardó en responderse/cerrarse la OM RECL00132.

Flujo / trazabilidad:
- Dame el flujo de la OM RECL00132 desde que se creó hasta que se cerró.
- Dame la trazabilidad, línea de tiempo o historial de la OM RECL00132.

Equipo de respuestas:
- Cuántas OM tienen equipo asignado.
- Cuántas OM no tienen equipo asignado.
- Miembros de equipo por OM.
- Miembro de equipo con más OM asignadas.
- Miembros con respuestas pendientes.
- Promedio de días de respuesta por miembro de equipo.
- OM con equipo asignado pero sin respuesta.

Acciones de control y correctivas:
- Qué acciones de control están por vencer.
- Qué acciones correctivas están por vencer.
- Qué acciones vencen en los próximos 5 días.
- Qué acciones están vencidas.
- Cuáles OM tienen acciones vencidas o por vencer.
- Qué usuarios no han cumplido sus acciones de control/correctivas.
- Qué sponsor tiene acciones vencidas o por vencer.
- Qué acciones vencieron esta semana / vencen esta semana / vencen este mes.
- OM con acciones de control/correctivas sin evidencia.
- Usuarios que no han cargado evidencia de acciones correctivas o de control.

Indicadores ejecutivos:
- Resumen general de OM.
- Top 10 procesos/clientes/sponsors con más OM.
- Top 10 OM con más días sin respuesta.
- Total de OM abiertas, cerradas y sin respuesta.
- Total de OM por mes y estado.
"""


def normalizar_pregunta(txt: str) -> str:
    txt = (txt or "").lower().strip()
    repl = {
        "á": "a", "é": "e", "í": "i", "ó": "o", "ú": "u",
        "ñ": "n", "¿": "", "?": "", ",": "", ".": "", ";": ""
    }
    for a, b in repl.items():
        txt = txt.replace(a, b)
    return " ".join(txt.split())


def cargar_reglas_modulo(conn, modulo: str):
    cur = conn.cursor()
    cur.execute("""
        SELECT patron
        FROM ai_chat_modulo_reglas
        WHERE modulo = ?
          AND activo = 1
          AND aprobado = 1
    """, (modulo,))
    return [r["patron"] for r in cur.fetchall()]


def pregunta_permitida_modulo(conn, pregunta_norm: str, modulo: str) -> bool:
    # 1) Sinónimos base: evita bloquear preguntas válidas como "tipo por cliente" o fechas.
    if any(p in pregunta_norm for p in PALABRAS_OM):
        return True

    # 2) Reglas configurables en BD.
    reglas = cargar_reglas_modulo(conn, modulo)
    reglas_norm = [normalizar_pregunta(x) for x in reglas]
    return any(r in pregunta_norm for r in reglas_norm)


def sugerir_regla(conn, modulo: str, pregunta_norm: str):
    palabras = pregunta_norm.split()
    if len(palabras) < 2:
        return

    patron = " ".join(palabras[:5])
    cur = conn.cursor()
    cur.execute("""
        SELECT TOP 1 id
        FROM ai_chat_modulo_reglas
        WHERE modulo = ?
          AND patron = ?
    """, (modulo, patron))

    if cur.fetchone():
        return

    cur.execute("""
        INSERT INTO ai_chat_modulo_reglas (modulo, patron, activo, aprobado)
        VALUES (?, ?, 0, 0)
    """, (modulo, patron))
    conn.commit()


def buscar_cache(conn, pregunta_norm: str):
    cur = conn.cursor()
    cur.execute("""
        SELECT TOP 1 id, sql_generado
        FROM om_chat_sql_cache
        WHERE pregunta_normalizada = ?
          AND activo = 1
        ORDER BY usos DESC, id DESC
    """, (pregunta_norm,))
    return cur.fetchone()


def guardar_cache(conn, pregunta_norm, pregunta_original, sql_generado, user_id=None):
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO om_chat_sql_cache (
            pregunta_normalizada,
            pregunta_original,
            sql_generado,
            creado_por
        )
        VALUES (?, ?, ?, ?)
    """, (pregunta_norm, pregunta_original, sql_generado, user_id))
    conn.commit()


def marcar_uso_cache(conn, cache_id):
    cur = conn.cursor()
    cur.execute("""
        UPDATE om_chat_sql_cache
        SET usos = usos + 1,
            ultimo_uso_at = GETDATE()
        WHERE id = ?
    """, (cache_id,))
    conn.commit()


def normalizar_sql_server(sql: str) -> str:
    sql = (sql or "").strip().rstrip(";")
    sql = re.sub(r"(?i)^SELECT\s+TOP\s+(\d+)\s+DISTINCT\s+", r"SELECT DISTINCT TOP \1 ", sql)
    return sql


def validar_sql_solo_select(sql: str) -> str:
    sql = (sql or "").strip().rstrip(";")
    upper = sql.upper()

    if not upper.startswith("SELECT"):
        raise ValueError("Solo se permiten consultas SELECT.")

    if ";" in sql:
        raise ValueError("No se permite ejecutar múltiples sentencias.")

    for palabra in PROHIBIDAS:
        if palabra in upper:
            raise ValueError(f"SQL no permitido: {palabra}")

    tablas_sql = re.findall(r"\b(?:FROM|JOIN)\s+([a-zA-Z0-9_\.]+)", sql, re.I)
    if not tablas_sql:
        raise ValueError("La consulta debe usar una vista permitida.")

    for t in tablas_sql:
        t_limpia = t.split(".")[-1].lower()
        if t_limpia not in TABLAS_PERMITIDAS:
            raise ValueError(f"Tabla no permitida: {t_limpia}")

    if " TOP " not in upper and "COUNT(" not in upper:
        sql = re.sub(r"^SELECT\s+", "SELECT TOP 100 ", sql, flags=re.I)

    return sql


def _like_param(valor: str) -> str:
    return f"%{(valor or '').strip()}%"


def _extraer_codigo_om(texto: str) -> str | None:
    m = re.search(r"\b(?:OM|RECL)[- ]?\d{3,}\b", texto or "", re.I)
    return m.group(0).replace(" ", "").upper() if m else None


def _extraer_ultimos_dias(pregunta_norm: str) -> int | None:
    m = re.search(r"ultimos\s+(\d+)\s+dias", pregunta_norm, re.I)
    if m:
        return int(m.group(1))
    return None


def sql_predefinido_vista(pregunta_norm: str, pregunta_original: str, user_id: int | None):
    uid = int(user_id or 0)
    texto = (pregunta_original or "").strip()
    codigo_om = _extraer_codigo_om(texto)

    # -------------------------
    # Totales personales
    # -------------------------

    if pregunta_norm in (
        "cuantas om estan por vencer las acciones de control y correctivas",
        "cuantas om tienen acciones de control y correctivas por vencer",
        "acciones de control y correctivas por vencer",
        "om con acciones por vencer",
        "cuantas om tienen acciones por vencer",
    ):
        return """
            SELECT
                tipo_accion,
                COUNT(DISTINCT reclamo_id) AS total_om,
                COUNT(*) AS total_acciones
            FROM vw_om_acciones_base
            WHERE estado_cumplimiento_accion = 'POR VENCER'
            AND UPPER(tipo_accion) IN ('CONTROL', 'CORRECTIVA')
            GROUP BY tipo_accion
            ORDER BY total_acciones DESC
        """, [], "predefinido_acciones"
    
    if pregunta_norm in (
        "cuantas om llevo hoy", "cuantas om tengo hoy",
        "cuantas oportunidades de mejora llevo hoy", "cuantas om ingrese hoy",
    ):
        return """
            SELECT COUNT(DISTINCT reclamo_id) AS total_om
            FROM vw_om_reporte_base
            WHERE creador_username IN (SELECT username FROM usuarios WHERE id = ?)
              AND TRY_CONVERT(date, fecha_creacion) = CAST(GETDATE() AS date)
        """, [uid], "predefinido_vista"

    if pregunta_norm in ("cuantas om llevo esta semana", "cuantas om tengo esta semana"):
        return """
            SELECT COUNT(DISTINCT reclamo_id) AS total_om
            FROM vw_om_reporte_base
            WHERE creador_username IN (SELECT username FROM usuarios WHERE id = ?)
              AND TRY_CONVERT(date, fecha_creacion) >= DATEADD(day, 1 - DATEPART(weekday, GETDATE()), CAST(GETDATE() AS date))
        """, [uid], "predefinido_vista"

    # -------------------------
    # Conteos generales
    # -------------------------
    if pregunta_norm in ("cuantas om hay en total", "total de om", "total om"):
        return """
            SELECT COUNT(DISTINCT reclamo_id) AS total_om
            FROM vw_om_reporte_base
        """, [], "predefinido_vista"

    if pregunta_norm in ("cuantas om hay abiertas", "total de om abiertas", "om abiertas"):
        return """
            SELECT COUNT(DISTINCT reclamo_id) AS total_om
            FROM vw_om_reporte_base
            WHERE LOWER(ISNULL(estado_global,'')) = 'abierto'
        """, [], "predefinido_vista"

    if pregunta_norm in ("cuantas om hay cerradas", "total de om cerradas", "om cerradas"):
        return """
            SELECT COUNT(DISTINCT reclamo_id) AS total_om
            FROM vw_om_reporte_base
            WHERE LOWER(ISNULL(estado_global,'')) = 'cerrado'
        """, [], "predefinido_vista"

    # -------------------------
    # Por cliente / proceso / tipo / sponsor / usuario
    # -------------------------
    if pregunta_norm in (
        "dame el numero de om por clientes", "numero de om por clientes", "numero de om por cliente",
        "cuantas om por clientes", "cuantas om hay por cliente", "om por cliente", "cuantas om hay por clientes",
    ):
        return """
            SELECT TOP 100
                ISNULL(cliente, 'SIN CLIENTE') AS cliente,
                COUNT(DISTINCT reclamo_id) AS total_om
            FROM vw_om_reporte_base
            GROUP BY ISNULL(cliente, 'SIN CLIENTE')
            ORDER BY total_om DESC
        """, [], "predefinido_vista"

    if pregunta_norm in ("que cliente tiene mas om", "cual cliente tiene mas om"):
        return """
            SELECT TOP 10
                ISNULL(cliente, 'SIN CLIENTE') AS cliente,
                COUNT(DISTINCT reclamo_id) AS total_om
            FROM vw_om_reporte_base
            GROUP BY ISNULL(cliente, 'SIN CLIENTE')
            ORDER BY total_om DESC
        """, [], "predefinido_vista"

    if pregunta_norm in (
        "cuantas om hay por proceso", "om por proceso", "om por departamento",
        "que proceso tiene mas om", "cual proceso tiene mas om", "que departamento tiene mas om", "cual departamento tiene mas om",
    ):
        return """
            SELECT TOP 100
                ISNULL(proceso, 'SIN PROCESO') AS proceso,
                COUNT(DISTINCT reclamo_id) AS total_om
            FROM vw_om_reporte_base
            GROUP BY ISNULL(proceso, 'SIN PROCESO')
            ORDER BY total_om DESC
        """, [], "predefinido_vista"

    if pregunta_norm in (
        "cuantas om hay por tipo de reclamo", "om por tipo de reclamo", "reclamos por tipo",
        "cual es el tipo de reclamo mas frecuente", "que tipo de reclamo tiene mas om",
    ):
        return """
            SELECT TOP 100
                ISNULL(tipo_reclamo, 'SIN TIPO') AS tipo_reclamo,
                COUNT(DISTINCT reclamo_id) AS total_om
            FROM vw_om_reporte_base
            GROUP BY ISNULL(tipo_reclamo, 'SIN TIPO')
            ORDER BY total_om DESC
        """, [], "predefinido_vista"

    if pregunta_norm in (
        "tipo de reclamo por cliente", "tipos de reclamo por cliente",
        "reclamos por tipo y cliente", "om por tipo de reclamo y cliente",
        "cuantas om por tipo de reclamo y cliente",
    ):
        return """
            SELECT TOP 100
                ISNULL(cliente, 'SIN CLIENTE') AS cliente,
                ISNULL(tipo_reclamo, 'SIN TIPO') AS tipo_reclamo,
                COUNT(DISTINCT reclamo_id) AS total_om
            FROM vw_om_reporte_base
            GROUP BY ISNULL(cliente, 'SIN CLIENTE'), ISNULL(tipo_reclamo, 'SIN TIPO')
            ORDER BY total_om DESC
        """, [], "predefinido_vista"

    if pregunta_norm in (
        "cuantas om tiene cada sponsor", "om por sponsor", "que sponsor tiene mas om asignadas",
        "quienes son los sponsor asignados", "quienes son los sponsors asignados",
        "cuales son los sponsor asignados", "cuales son los sponsors asignados",
    ):
        return """
            SELECT TOP 100
                sponsor_username,
                sponsor_nombre,
                COUNT(DISTINCT reclamo_id) AS total_om
            FROM vw_om_reporte_base
            WHERE ISNULL(sponsor_nombre, '') <> ''
            GROUP BY sponsor_username, sponsor_nombre
            ORDER BY total_om DESC
        """, [], "predefinido_vista"

    if pregunta_norm in (
        "cuantas om creo cada usuario", "om por usuario", "que usuario creo mas om",
        "cuantas om creo cada usuario por mes",
    ):
        if "por mes" in pregunta_norm:
            return """
                SELECT TOP 100
                    FORMAT(TRY_CONVERT(date, fecha_creacion), 'yyyy-MM') AS mes,
                    creador_username,
                    creador_nombre,
                    COUNT(DISTINCT reclamo_id) AS total_om
                FROM vw_om_reporte_base
                GROUP BY FORMAT(TRY_CONVERT(date, fecha_creacion), 'yyyy-MM'), creador_username, creador_nombre
                ORDER BY mes DESC, total_om DESC
            """, [], "predefinido_vista"
        return """
            SELECT TOP 100
                creador_username,
                creador_nombre,
                COUNT(DISTINCT reclamo_id) AS total_om
            FROM vw_om_reporte_base
            GROUP BY creador_username, creador_nombre
            ORDER BY total_om DESC
        """, [], "predefinido_vista"

    # -------------------------
    # Fechas / tendencias
    # -------------------------
    if pregunta_norm in (
        "cuantas om se crearon por mes", "om creadas por mes", "frecuencia de creacion de om por mes",
        "frecuencia promedio de creacion de om por mes",
    ):
        return """
            SELECT
                FORMAT(TRY_CONVERT(date, fecha_creacion), 'yyyy-MM') AS mes,
                COUNT(DISTINCT reclamo_id) AS total_om
            FROM vw_om_reporte_base
            WHERE TRY_CONVERT(date, fecha_creacion) IS NOT NULL
            GROUP BY FORMAT(TRY_CONVERT(date, fecha_creacion), 'yyyy-MM')
            ORDER BY mes DESC
        """, [], "predefinido_vista"

    if pregunta_norm in (
        "cuantas om se crearon por dia", "om creadas por dia", "frecuencia de creacion de om por dia",
    ):
        return """
            SELECT
                TRY_CONVERT(date, fecha_creacion) AS fecha,
                COUNT(DISTINCT reclamo_id) AS total_om
            FROM vw_om_reporte_base
            WHERE TRY_CONVERT(date, fecha_creacion) IS NOT NULL
            GROUP BY TRY_CONVERT(date, fecha_creacion)
            ORDER BY fecha DESC
        """, [], "predefinido_vista"

    if pregunta_norm in (
        "cuantas om se crearon en mayo", "om creadas en mayo", "cuantas om creo cada usuario en mayo",
        "cuantas om se crearon cada dia de mayo",
    ):
        if "cada usuario" in pregunta_norm:
            return """
                SELECT TOP 100
                    creador_username,
                    creador_nombre,
                    COUNT(DISTINCT reclamo_id) AS total_om
                FROM vw_om_reporte_base
                WHERE MONTH(TRY_CONVERT(date, fecha_creacion)) = 5
                GROUP BY creador_username, creador_nombre
                ORDER BY total_om DESC
            """, [], "predefinido_vista"
        if "cada dia" in pregunta_norm:
            return """
                SELECT
                    TRY_CONVERT(date, fecha_creacion) AS fecha,
                    COUNT(DISTINCT reclamo_id) AS total_om
                FROM vw_om_reporte_base
                WHERE MONTH(TRY_CONVERT(date, fecha_creacion)) = 5
                GROUP BY TRY_CONVERT(date, fecha_creacion)
                ORDER BY fecha DESC
            """, [], "predefinido_vista"
        return """
            SELECT COUNT(DISTINCT reclamo_id) AS total_om
            FROM vw_om_reporte_base
            WHERE MONTH(TRY_CONVERT(date, fecha_creacion)) = 5
        """, [], "predefinido_vista"

    if pregunta_norm in (
        "total de om cerradas por mes", "om cerradas por mes",
        "cuantas om cerradas por mes", "total om cerradas por mes",
    ):
        return """
            SELECT
                FORMAT(TRY_CONVERT(date, fecha_reclamo), 'yyyy-MM') AS mes,
                COUNT(DISTINCT reclamo_id) AS total_om
            FROM vw_om_reporte_base
            WHERE LOWER(ISNULL(estado_global, '')) = 'cerrado'
              AND TRY_CONVERT(date, fecha_reclamo) IS NOT NULL
            GROUP BY FORMAT(TRY_CONVERT(date, fecha_reclamo), 'yyyy-MM')
            ORDER BY mes DESC
        """, [], "predefinido_vista"

    dias = _extraer_ultimos_dias(pregunta_norm)
    if dias and ("cerraron" in pregunta_norm or "cerradas" in pregunta_norm or "cerrada" in pregunta_norm):
        return """
            SELECT COUNT(DISTINCT reclamo_id) AS total_om
            FROM vw_om_reporte_base
            WHERE LOWER(ISNULL(estado_global, '')) = 'cerrado'
              AND TRY_CONVERT(date, fecha_aprobacion_respuesta) >= DATEADD(day, -?, CAST(GETDATE() AS date))
        """, [dias], "predefinido_vista"

    # -------------------------
    # Tiempos de respuesta
    # -------------------------
    if pregunta_norm in (
        "promedio de dias de respuesta por sponsor", "dias promedio de respuesta por sponsor",
        "tiempo promedio de respuesta por sponsor", "que sponsor tarda mas en responder",
    ):
        return """
            SELECT TOP 100
                sponsor_username,
                sponsor_nombre,
                AVG(CAST(dias_respuesta_sponsor AS decimal(18,2))) AS dias_promedio_respuesta,
                COUNT(DISTINCT reclamo_id) AS total_om
            FROM vw_om_reporte_base
            WHERE dias_respuesta_sponsor IS NOT NULL
            GROUP BY sponsor_username, sponsor_nombre
            ORDER BY dias_promedio_respuesta DESC
        """, [], "predefinido_vista"

    if pregunta_norm in (
        "promedio de dias de respuesta por proceso", "dias promedio de respuesta por proceso",
        "que proceso tiene mayor demora promedio de respuesta",
    ):
        return """
            SELECT TOP 100
                ISNULL(proceso, 'SIN PROCESO') AS proceso,
                AVG(CAST(dias_respuesta_sponsor AS decimal(18,2))) AS dias_promedio_respuesta,
                COUNT(DISTINCT reclamo_id) AS total_om
            FROM vw_om_reporte_base
            WHERE dias_respuesta_sponsor IS NOT NULL
            GROUP BY ISNULL(proceso, 'SIN PROCESO')
            ORDER BY dias_promedio_respuesta DESC
            """, [], "predefinido_vista"


    if pregunta_norm in (
        "cuantas om tienen acciones vencidas",
        "cuantas om estan vencidas las acciones de control y correctivas",
    ):
        return """
            SELECT
                tipo_accion,
                COUNT(DISTINCT reclamo_id) AS total_om,
                COUNT(*) AS total_acciones
            FROM vw_om_acciones_base
            WHERE estado_cumplimiento_accion = 'VENCIDA'
            AND UPPER(tipo_accion) IN ('CONTROL', 'CORRECTIVA')
            GROUP BY tipo_accion
            ORDER BY total_acciones DESC
        """, [], "predefinido_acciones"
    if pregunta_norm in (
        "cuales om tienen acciones por vencer",
        "dame las om con acciones por vencer",
        "que acciones estan por vencer",
        "cuales son las acciones por vencer",
    ):
        return """
            SELECT TOP 100
                codigo_om,
                cliente,
                proceso,
                sponsor_nombre,
                tipo_accion,
                descripcion_accion,
                fecha_compromiso,
                dias_para_vencer,
                estado_cumplimiento_accion
            FROM vw_om_acciones_base
            WHERE estado_cumplimiento_accion = 'POR VENCER'
            AND UPPER(tipo_accion) IN ('CONTROL', 'CORRECTIVA')
            ORDER BY dias_para_vencer ASC
        """, [], "predefinido_acciones"
    if pregunta_norm in (
        "cuales om tienen mas dias sin respuesta", "om con mas dias sin respuesta",
        "top 10 de om con mas dias sin respuesta",
    ):
        return """
            SELECT TOP 10
                codigo_om,
                cliente,
                proceso,
                sponsor_nombre,
                dias_sin_respuesta_sponsor,
                estado_global
            FROM vw_om_reporte_base
            WHERE ISNULL(dias_sin_respuesta_sponsor, 0) > 0
            ORDER BY dias_sin_respuesta_sponsor DESC
        """, [], "predefinido_vista"

    if codigo_om and (
        "tiempo de respuesta" in pregunta_norm or "dias tardo" in pregunta_norm or "cuantos dias" in pregunta_norm
        or "estuvo abierta" in pregunta_norm
    ):
        return """
            SELECT TOP 10
                codigo_om,
                fecha_creacion,
                fecha_reclamo,
                fecha_respuesta_imputado,
                fecha_aprobacion_respuesta,
                dias_respuesta_sponsor,
                dias_sin_respuesta_sponsor,
                estado_global,
                sponsor_nombre
            FROM vw_om_reporte_base
            WHERE UPPER(codigo_om) = UPPER(?)
            ORDER BY imputacion_id DESC
        """, [codigo_om], "predefinido_vista"

    if codigo_om and ("flujo" in pregunta_norm or "trazabilidad" in pregunta_norm or "linea de tiempo" in pregunta_norm or "historial" in pregunta_norm):
        return """
            SELECT TOP 10
                codigo_om,
                fecha_creacion,
                fecha_reclamo,
                creador_nombre,
                sponsor_nombre,
                jefe_nombre,
                fecha_primera_asignacion_equipo,
                miembros_equipo,
                fecha_primera_respuesta_equipo,
                fecha_respuesta_imputado,
                fecha_aprobacion_respuesta,
                fecha_rechazo_respuesta,
                estado_global,
                estado_asignacion,
                estado_respuesta,
                dias_respuesta_sponsor,
                respuesta_causa,
                respuesta_preventiva,
                respuesta_correctiva
            FROM vw_om_reporte_base
            WHERE UPPER(codigo_om) = UPPER(?)
            ORDER BY imputacion_id DESC
        """, [codigo_om], "predefinido_vista"

    # -------------------------
    # Equipo
    # -------------------------
    if pregunta_norm in (
        "cuantas om tienen equipo asignado", "om con equipo asignado", "cuantas om no tienen equipo asignado",
    ):
        if "no tienen" in pregunta_norm:
            return """
                SELECT COUNT(DISTINCT reclamo_id) AS total_om
                FROM vw_om_reporte_base
                WHERE ISNULL(total_miembros_equipo, 0) = 0
            """, [], "predefinido_vista"
        return """
            SELECT COUNT(DISTINCT reclamo_id) AS total_om
            FROM vw_om_reporte_base
            WHERE ISNULL(total_miembros_equipo, 0) > 0
        """, [], "predefinido_vista"

    if pregunta_norm in (
        "promedio de dias de respuesta por miembro de equipo",
        "que miembro de equipo tarda mas en responder",
    ):
        return """
            SELECT TOP 100
                miembros_equipo,
                AVG(CAST(dias_promedio_respuesta_equipo AS decimal(18,2))) AS dias_promedio_respuesta_equipo,
                COUNT(DISTINCT reclamo_id) AS total_om
            FROM vw_om_reporte_base
            WHERE ISNULL(miembros_equipo, '') <> ''
              AND dias_promedio_respuesta_equipo IS NOT NULL
            GROUP BY miembros_equipo
            ORDER BY dias_promedio_respuesta_equipo DESC
        """, [], "predefinido_vista"

    # -------------------------
    # Acciones control/correctiva: usa vw_om_acciones_base
    # -------------------------
    if any(x in pregunta_norm for x in ["acciones por vencer", "acciones vencen", "estan por vencer", "por cumplir su fecha"]):
        return """
            SELECT TOP 100
                codigo_om,
                cliente,
                proceso,
                sponsor_nombre,
                tipo_accion,
                descripcion_accion,
                fecha_compromiso,
                dias_para_vencer,
                estado_cumplimiento_accion
            FROM vw_om_acciones_base
            WHERE estado_cumplimiento_accion = 'POR VENCER'
            ORDER BY fecha_compromiso ASC
        """, [], "predefinido_acciones"

    if any(x in pregunta_norm for x in ["acciones vencidas", "acciones vencieron", "estan vencidas", "vencidas"]):
        return """
            SELECT TOP 100
                codigo_om,
                cliente,
                proceso,
                sponsor_nombre,
                tipo_accion,
                descripcion_accion,
                fecha_compromiso,
                dias_para_vencer,
                estado_cumplimiento_accion
            FROM vw_om_acciones_base
            WHERE estado_cumplimiento_accion = 'VENCIDA'
            ORDER BY fecha_compromiso ASC
        """, [], "predefinido_acciones"

    if "sin evidencia" in pregunta_norm or "no han cargado evidencia" in pregunta_norm:
        return """
            SELECT TOP 100
                codigo_om,
                cliente,
                proceso,
                sponsor_nombre,
                tipo_accion,
                descripcion_accion,
                fecha_compromiso,
                estado_cumplimiento_accion
            FROM vw_om_acciones_base
            WHERE ISNULL(requiere_evidencia, 0) = 1
              AND ISNULL(tiene_evidencia, 0) = 0
            ORDER BY fecha_compromiso ASC
        """, [], "predefinido_acciones"

    if "no han cumplido" in pregunta_norm or "no han cargado sus acciones" in pregunta_norm:
        return """
            SELECT TOP 100
                codigo_om,
                cliente,
                proceso,
                sponsor_nombre,
                tipo_accion,
                descripcion_accion,
                fecha_compromiso,
                estado_cumplimiento_accion
            FROM vw_om_acciones_base
            WHERE ISNULL(cumplido, 0) = 0
            ORDER BY fecha_compromiso ASC
        """, [], "predefinido_acciones"

    # -------------------------
    # Búsqueda genérica "cuántas OM tiene X"
    # -------------------------
    m = re.search(r"cu[aá]ntas?\s+om\s+tiene\s+(.+)", texto, re.I)
    if m:
        termino = m.group(1).strip()
        return """
            SELECT
                ? AS busqueda,
                COUNT(DISTINCT reclamo_id) AS total_om
            FROM vw_om_reporte_base
            WHERE UPPER(ISNULL(proceso, '')) LIKE UPPER(?)
               OR UPPER(ISNULL(proceso_text, '')) LIKE UPPER(?)
               OR UPPER(ISNULL(sponsor_nombre, '')) LIKE UPPER(?)
               OR UPPER(ISNULL(sponsor_username, '')) LIKE UPPER(?)
               OR UPPER(ISNULL(imputado_nombre, '')) LIKE UPPER(?)
               OR UPPER(ISNULL(imputado_username, '')) LIKE UPPER(?)
               OR UPPER(ISNULL(creador_nombre, '')) LIKE UPPER(?)
               OR UPPER(ISNULL(creador_username, '')) LIKE UPPER(?)
               OR UPPER(ISNULL(jefe_nombre, '')) LIKE UPPER(?)
               OR UPPER(ISNULL(jefe_username, '')) LIKE UPPER(?)
               OR UPPER(ISNULL(miembros_equipo, '')) LIKE UPPER(?)
               OR UPPER(ISNULL(cliente, '')) LIKE UPPER(?)
               OR UPPER(ISNULL(cliente_nombre, '')) LIKE UPPER(?)
        """, [
            termino,
            _like_param(termino), _like_param(termino),
            _like_param(termino), _like_param(termino),
            _like_param(termino), _like_param(termino),
            _like_param(termino), _like_param(termino),
            _like_param(termino), _like_param(termino),
            _like_param(termino),
            _like_param(termino), _like_param(termino),
        ], "predefinido_vista_busqueda"

    return None


def generar_sql_openai(pregunta: str) -> str:
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

    prompt = f"""
Eres un asistente EXCLUSIVO para consultar datos de Oportunidades de Mejora.

OM, Oportunidad de Mejora, Oportunidades de Mejora, Reclamo y Reclamos significan lo mismo.
Si la pregunta está relacionada con cualquiera de esos términos o con clientes, procesos, sponsors,
usuarios, fechas, estados, respuestas, tiempos, equipo, acciones de control/correctivas, evidencias,
vencimientos o cumplimiento, debe considerarse válida.

Devuelve SOLO JSON válido:
{{"sql":"SELECT ..."}}

Si realmente no está relacionada, devuelve:
{{"sql":""}}

Vistas disponibles y autorizadas:
1) vw_om_reporte_base
2) vw_om_acciones_base

Columnas de vw_om_reporte_base:
reclamo_id, codigo_om, fecha_reclamo, fecha_creacion,
creador_username, creador_nombre,
tipo_om, tipo_tramite, tipo_reclamo, tipo_tramite_codigo,
proceso_text, proceso,
cliente_nombre, cliente, cliente_identificacion, cliente_contacto,
cliente_email, cliente_telefono, material_desc, ciudad,
observacion, procede, estado_global,
imputacion_id,
imputado_username, sponsor_username,
imputado_nombre, sponsor_nombre,
jefe_username, jefe_nombre,
estado_asignacion, fecha_aprobacion_asignacion,
fecha_rechazo_asignacion, motivo_rechazo_asignacion,
respuesta_causa, respuesta_preventiva, respuesta_correctiva,
fecha_causa, fecha_preventiva, fecha_correctiva,
fecha_respuesta_imputado,
dias_respuesta_sponsor, dias_sin_respuesta_sponsor,
miembros_equipo, total_miembros_equipo,
fecha_primera_asignacion_equipo, dias_promedio_asignacion_equipo,
miembros_equipo_respondieron, miembros_equipo_pendientes,
fecha_primera_respuesta_equipo, dias_promedio_respuesta_equipo,
dias_promedio_sin_respuesta_equipo, dias_max_sin_respuesta_equipo,
estado_respuesta, fecha_aprobacion_respuesta,
fecha_rechazo_respuesta, motivo_rechazo_respuesta.

Columnas esperadas de vw_om_acciones_base:
reclamo_id, codigo_om, fecha_reclamo, fecha_creacion, estado_global,
proceso, cliente, sponsor_username, sponsor_nombre,
tipo_accion, descripcion_accion, fecha_compromiso, fecha_cumplimiento,
cumplido, requiere_evidencia, tiene_evidencia,
estado_cumplimiento_accion, dias_para_vencer.

Reglas obligatorias:
- Solo SQL Server SELECT.
- No uses tablas físicas.
- No uses INSERT, UPDATE, DELETE, DROP, ALTER, TRUNCATE, MERGE, EXEC.
- Para conteos de OM usa COUNT(DISTINCT reclamo_id).
- Para listados usa TOP 100.
- Para preguntas de acciones, vencimientos, evidencia o cumplimiento usa vw_om_acciones_base.
- Para preguntas generales de OM usa vw_om_reporte_base.
- "cerradas" significa LOWER(estado_global) = 'cerrado'.
- "abiertas" significa LOWER(estado_global) = 'abierto'.
- "por mes" significa agrupar por FORMAT(TRY_CONVERT(date, fecha), 'yyyy-MM').
- Para creación usa fecha_creacion.
- Para fecha OM usa fecha_reclamo.
- Para cierre usa fecha_aprobacion_respuesta si existe; si no, usa fecha_respuesta_imputado.
- "últimos N días" significa fecha >= DATEADD(day, -N, CAST(GETDATE() AS date)).
- "por vencer" significa estado_cumplimiento_accion = 'POR VENCER'.
- "vencida" significa estado_cumplimiento_accion = 'VENCIDA'.
- "cumplida" significa cumplido = 1.
- Para buscar una OM específica usa codigo_om.
- Para tiempo de respuesta usa dias_respuesta_sponsor.
- Para días sin respuesta usa dias_sin_respuesta_sponsor.
- No inventes columnas.

{PREGUNTAS_GUIA}

Pregunta del usuario:
{pregunta}
"""

    completion = client.chat.completions.create(
        model=OPENAI_MODEL,
        messages=[
            {"role": "developer", "content": "Devuelve únicamente JSON válido. No expliques."},
            {"role": "user", "content": prompt},
        ],
    )

    raw = completion.choices[0].message.content.strip()
    data = json.loads(raw)
    sql = (data.get("sql") or "").strip()

    if not sql:
        raise ValueError("La pregunta no está relacionada con Oportunidades de Mejora.")

    return sql


def ejecutar_sql(conn, sql, params=None):
    cur = conn.cursor()
    cur.execute(sql, params or [])
    cols = [c[0] for c in cur.description]
    data = []
    for row in cur.fetchall():
        data.append({cols[i]: row[i] for i in range(len(cols))})
    return data


def cargar_diccionario_campos(conn, modulo="om"):
    cur = conn.cursor()
    cur.execute("""
        SELECT columna, etiqueta, visible, sensible
        FROM ai_chat_campos_diccionario
        WHERE modulo = ?
          AND activo = 1
    """, (modulo,))

    dic = {}
    for r in cur.fetchall():
        dic[r["columna"].lower()] = {
            "etiqueta": r["etiqueta"],
            "visible": bool(r["visible"]),
            "sensible": bool(r["sensible"]),
        }
    return dic


def responder_simple(conn, pregunta: str, data: list[dict], modulo="om"):
    if not data:
        return "No encontré resultados para esa consulta."

    if len(data) == 1:
        row = data[0]
        if "total_om" in row:
            return f"Resultado: {row.get('total_om', 0)} OM."
        if "total" in row:
            return f"Resultado: {row.get('total', 0)}."

    dic = cargar_diccionario_campos(conn, modulo)
    filas = []

    for row in data[:10]:
        partes = []
        for k, v in row.items():
            k_norm = k.lower()
            cfg = dic.get(k_norm)
            if cfg:
                if not cfg["visible"] or cfg["sensible"]:
                    continue
                etiqueta = cfg["etiqueta"]
            else:
                if k_norm.endswith("_id") or k_norm == "id":
                    continue
                etiqueta = k.replace("_", " ").capitalize()

            partes.append(f"{etiqueta}: {v if v is not None else '—'}")

        if partes:
            filas.append(" | ".join(partes))

    if not filas:
        return f"Encontré {len(data)} resultado(s), pero no hay campos visibles para mostrar."

    return "Estos son los principales resultados:\n" + "\n".join(filas)


def om_chat_responder(pregunta: str, user_id: int | None):
    conn = get_db()
    pregunta_norm = normalizar_pregunta(pregunta)
    sql = None
    params = []
    source = "desconocido"

    try:
        if not pregunta_permitida_modulo(conn, pregunta_norm, "om"):
            return {
                "ok": False,
                "error": "Solo puedo responder preguntas relacionadas con Oportunidades de Mejora."
            }

        pre = sql_predefinido_vista(pregunta_norm, pregunta, user_id)
        if pre:
            sql, params, source = pre

        if not sql:
            cache = buscar_cache(conn, pregunta_norm)
            if cache:
                sql_cache = normalizar_sql_server(cache["sql_generado"])
                try:
                    sql_cache = validar_sql_solo_select(sql_cache)
                    sql = sql_cache
                    params = []
                    marcar_uso_cache(conn, cache["id"])
                    source = "cache"
                except Exception:
                    sql = None
                    params = []

        if not sql:
            sql = generar_sql_openai(pregunta)
            sql = normalizar_sql_server(sql)
            sql = validar_sql_solo_select(sql)
            guardar_cache(conn, pregunta_norm, pregunta, sql, user_id)
            sugerir_regla(conn, "om", pregunta_norm)
            source = "openai"

        sql = normalizar_sql_server(sql)
        sql = validar_sql_solo_select(sql)

        data = ejecutar_sql(conn, sql, params)
        respuesta = responder_simple(conn, pregunta, data, "om")

        return {
            "ok": True,
            "source": source,
            "sql": sql,
            "rows": data[:50],
            "respuesta": respuesta,
        }

    except pyodbc.ProgrammingError:
        log.exception("SQL inválido generado por asistente OM. SQL=%s", sql)
        return {
            "ok": True,
            "source": source,
            "rows": [],
            "respuesta": "No pude interpretar correctamente esa pregunta. Intenta reformularla con más detalle."
        }

    except Exception:
        log.exception("Error general en asistente OM")
        return {
            "ok": True,
            "source": source,
            "rows": [],
            "respuesta": "No pude procesar la consulta en este momento."
        }

    finally:
        try:
            conn.close()
        except Exception:
            pass
