import os
from flask import Flask, request
from werkzeug.middleware.proxy_fix import ProxyFix

# === App constants ===
APP_SECRET = os.environ.get("BITACORA_SECRET")  # si está, la usamos como SECRET_KEY
DB_PATH = os.path.join('database', 'bitacora.db')

ESTADOS = [
    "Por iniciar",
    "En desarrollo",
    "Atrasada",
    "Terminado","Cancelada",
    "Cerrado por sistema",
]
ROLES = ["admin", "jefe", "usuario"]
TABLE_GASTOS = 'gastos_tarjeta'
ALLOWED_EXTENSIONS = {'pdf', 'doc', 'docx', 'xls', 'xlsx', 'png', 'jpg', 'jpeg', 'gif'}


# -----------------------------
# Helpers
# -----------------------------
def _bool_env(name: str, default: bool = False) -> bool:
    val = os.environ.get(name)
    if val is None:
        return default
    return str(val).strip().lower() in ("1", "true", "t", "yes", "y")


def _ensure_secret_key(app: Flask):
    """
    Garantiza que SECRET_KEY sea estable:
    - Si existe BITACORA_SECRET en el entorno, úsala.
    - Si no, intenta leer secret_key.txt (un nivel arriba del paquete).
    - Si no existe, la crea una sola vez y la reutiliza.
    """
    if APP_SECRET:
        app.secret_key = APP_SECRET
        return

    # Archivo junto al repo (un nivel arriba del paquete)
    secret_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'secret_key.txt'))
    try:
        if os.path.exists(secret_path):
            with open(secret_path, 'r', encoding='utf-8') as f:
                key = (f.read() or '').strip()
                if key:
                    app.secret_key = key
                    return
        # Si no existe o está vacío, generamos y persistimos
        key = os.urandom(32).hex()
        os.makedirs(os.path.dirname(secret_path), exist_ok=True)
        with open(secret_path, 'w', encoding='utf-8') as f:
            f.write(key)
        app.secret_key = key
    except Exception:
        # Último recurso (no persistente): evita romper el arranque
        app.secret_key = os.urandom(32)


def _is_dev_like() -> bool:
    """
    Considera 'dev' si:
    - FLASK_ENV=development, o
    - FLASK_DEBUG=1, o
    - ENV=development
    """
    return (
        os.environ.get('FLASK_ENV') == 'development' or
        os.environ.get('FLASK_DEBUG') in ('1', 'true', 'True') or
        os.environ.get('ENV') == 'development'
    )


# -----------------------------
# Configuración principal
# -----------------------------
def configure_app(app: Flask):
    """Aplica configuración al objeto Flask y asegura rutas/carpetas."""
    _ensure_secret_key(app)

    # Carpeta de uploads dentro de static
    upload_folder = os.path.join(app.static_folder, 'uploads')
    os.makedirs(upload_folder, exist_ok=True)
    app.config['UPLOAD_FOLDER'] = upload_folder

    # ¿Confiamos en cabeceras de proxy? (si usas Nginx/ALB/Cloudflare)
    if _bool_env("TRUST_PROXY", False):
        # ajusta x_* si tu proxy reescribe más saltos
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_port=1, x_prefix=1)

    # Valor inicial de cookie secure:
    # - Si COOKIE_SECURE está definido, lo respetamos SIEMPRE.
    # - Si no, lo dejaremos en False y lo activaremos por-request cuando detectemos HTTPS.
    cookie_secure_override = os.environ.get("COOKIE_SECURE")  # "1" / "0" / None
    if cookie_secure_override is not None:
        session_cookie_secure = _bool_env("COOKIE_SECURE", False)
    else:
        # Por defecto: en dev-like asumimos HTTP; en prod podría ser HTTPS detrás de proxy.
        # Lo ajustaremos dinámicamente en cada request.
        session_cookie_secure = False

    # Config base (se puede modificar per-request)
    app.config.update(
        APP_SECRET=app.secret_key,
        DB_PATH=DB_PATH,
        ESTADOS=ESTADOS,
        ROLES=ROLES,
        TABLE_GASTOS=TABLE_GASTOS,
        ALLOWED_EXTENSIONS=ALLOWED_EXTENSIONS,

        # Cookies de sesión
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=session_cookie_secure,  # puede cambiarse per-request

        # 8 horas de sesión permanente
        PERMANENT_SESSION_LIFETIME=60 * 60 * 8,

        # Esquema por defecto (se ajusta abajo si hay override o detección de https)
        PREFERRED_URL_SCHEME="https" if session_cookie_secure else "http",
    )

    # -----------------------------
    # Auto-detección por-request del esquema (HTTP/HTTPS)
    # Sólo se aplica si NO hay override de COOKIE_SECURE
    # -----------------------------
    if cookie_secure_override is None:
        @app.before_request
        def _adapt_cookie_secure_by_request():
            """
            Si la petición llega como HTTPS (request.is_secure) o vía proxy con
            X-Forwarded-Proto=https, activamos SESSION_COOKIE_SECURE para ESTA request;
            si llega por HTTP en LAN, lo dejamos en False (para que el navegador acepte la cookie).
            """
            try:
                xf_proto = (request.headers.get("X-Forwarded-Proto") or "").split(",")[0].strip().lower()
                via_https = request.is_secure or xf_proto == "https"
                app.config['SESSION_COOKIE_SECURE'] = bool(via_https)
                app.config['PREFERRED_URL_SCHEME'] = "https" if via_https else "http"
            except Exception:
                # Fallback seguro
                app.config['SESSION_COOKIE_SECURE'] = False
                app.config['PREFERRED_URL_SCHEME'] = "http"
    else:
        # Si hay override, fija también el esquema preferido de URLs
        app.config['PREFERRED_URL_SCHEME'] = "https" if app.config['SESSION_COOKIE_SECURE'] else "http"
