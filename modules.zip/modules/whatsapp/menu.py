# modules/whatsapp/menu.py

MENU_TEXTO = """
🤖 Bienvenido al soporte automático.

Seleccione una opción:

1️⃣
2️⃣ 
3️⃣ Estado ticket
4️⃣ Hablar con soporte
5️⃣ Estado de OM
"""