# modules/whatsapp/webhook.py

from flask import Blueprint, request
from modules.whatsapp.sender import enviar_whatsapp
from modules.whatsapp.menu import MENU_TEXTO
from modules.whatsapp.states import (
    user_states,
    MENU_PRINCIPAL,
    MODO_OM
)

from modules.routes_reclamos import om_chat_responder

whatsapp_bp = Blueprint("whatsapp", __name__)

VERIFY_TOKEN = "mi_token_seguro"


# ==========================================
# VALIDACION META WEBHOOK
# ==========================================

@whatsapp_bp.route("/webhook", methods=["GET"])
def verify():

    mode = request.args.get("hub.mode")
    token = request.args.get("hub.verify_token")
    challenge = request.args.get("hub.challenge")

    if mode == "subscribe" and token == VERIFY_TOKEN:
        return challenge, 200

    return "Error", 403


# ==========================================
# RECIBIR MENSAJES
# ==========================================

@whatsapp_bp.route("/webhook", methods=["POST"])
def recibir_mensaje():

    data = request.json

    try:

        entry = data["entry"][0]
        changes = entry["changes"][0]
        value = changes["value"]

        messages = value.get("messages")

        if not messages:
            return "ok", 200

        mensaje = messages[0]["text"]["body"]
        numero = messages[0]["from"]

        mensaje = mensaje.strip()

        manejar_mensaje(numero, mensaje)

        return "ok", 200

    except Exception as e:
        print(e)
        return "error", 500


# ==========================================
# LOGICA PRINCIPAL
# ==========================================

def manejar_mensaje(numero, mensaje):

    estado = user_states.get(numero)

    # ======================================
    # MENU PRINCIPAL
    # ======================================

    if mensaje.lower() in ["hola", "menu", "inicio"]:

        user_states[numero] = MENU_PRINCIPAL

        enviar_whatsapp(numero, MENU_TEXTO)
        return

    # ======================================
    # OPCION 1
    # ======================================

    if mensaje == "1":

        enviar_whatsapp(
            numero,
            "🔓 Función desbloqueo usuario en construcción."
        )

        return

    # ======================================
    # OPCION 2
    # ======================================

    if mensaje == "2":

        enviar_whatsapp(
            numero,
            "🔑 Función reset contraseña en construcción."
        )

        return

    # ======================================
    # OPCION 3
    # ======================================

    if mensaje == "3":

        enviar_whatsapp(
            numero,
            "🎫 Estado ticket en construcción."
        )

        return

    # ======================================
    # OPCION 4
    # ======================================

    if mensaje == "4":

        enviar_whatsapp(
            numero,
            "👨‍💻 Un agente de soporte lo atenderá."
        )

        return

    # ======================================
    # OPCION 5 - OM
    # ======================================

    if mensaje == "5":

        user_states[numero] = MODO_OM

        enviar_whatsapp(
            numero,
            """📊 Módulo OM activado.

Ingrese su consulta.

Ejemplos:
- cuantas om hay abiertas
- acciones vencidas
- estado de la om RECL00132
"""
        )

        return

    # ======================================
    # MODO OM
    # ======================================

    if estado == MODO_OM:

        resultado = om_chat_responder(
            pregunta=mensaje,
            user_id=1
        )

        respuesta = resultado.get(
            "respuesta",
            "No pude procesar la consulta."
        )

        enviar_whatsapp(numero, respuesta)

        return

    # ======================================
    # DEFAULT
    # ======================================

    enviar_whatsapp(
        numero,
        "No entendí el mensaje. Escriba MENU."
    )