from flask import jsonify, request, current_app
from .db import get_db
from .security import require_login

def register_terceros_api(app):

    @app.route('/api/proveedores/search', methods=['GET'], endpoint='api_proveedores_search')
    @require_login
    def api_proveedores_search():
        q = (request.args.get('q') or '').strip()
        try:
            limit = int(request.args.get('limit', 5))
        except ValueError:
            limit = 5
        limit = max(1, min(limit, 5))

        conn = get_db(); cur = conn.cursor()
        base = """
        SELECT id, nombre
        FROM terceros
        WHERE UPPER(TRIM(tipo))='P'
            AND COALESCE(activo,1)=1
            AND TRIM(COALESCE(nombre,'')) <> ''
        """
        args = []
        if q:
            base += " AND LOWER(nombre) LIKE LOWER(?)"
            args.append(f"%{q}%")
        base += " ORDER BY nombre LIMIT ?"
        args.append(limit)

        cur.execute(base, args)
        out = [{"id": r["id"], "nombre": r["nombre"]} for r in cur.fetchall()]
        conn.close()
        return jsonify(out)
