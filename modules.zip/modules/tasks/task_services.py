from __future__ import annotations

from collections import defaultdict
from datetime import date, datetime, timedelta
import io
import smtplib
import secrets
from flask import url_for
from modules.tasks.task_notifications import _send_encuesta_satisfaccion_mail
import pandas as pd
from flask import session
from openpyxl.styles import Font

from modules.config import ESTADOS
from modules.db import get_db, get_config_value
from modules.tasks.task_notifications import _send_tarea_avance_mail
from modules.tasks.task_repository import (
    repo_obtener_tarea_para_encuesta,
    repo_obtener_encuesta_por_tarea,
    repo_insertar_encuesta,
    repo_marcar_encuesta_enviada,
    repo_obtener_encuesta_por_token,
    repo_insertar_respuesta_encuesta,
    repo_finalizar_encuesta,
    repo_listar_encuestas,
    repo_obtener_departamentos_tareas,
    repo_dashboard_tareas,
    repo_eliminar_tarea,
    repo_es_responsable_tarea,
    repo_find_user_id_by_email,
    repo_insertar_tarea,
    repo_insertar_tarea_accion,
    repo_insertar_tarea_responsable_si_no_existe,
    repo_listar_tarea_responsables_map,
    repo_listar_tareas_raw,
    repo_obtener_accion_con_tarea,
    repo_obtener_email_usuario,
    repo_obtener_emails_responsables_tarea,
    repo_obtener_empresas_activas,
    repo_obtener_responsables,
    repo_obtener_solicitantes,
    repo_obtener_tarea_acciones,
    repo_obtener_tarea_detalle,
    repo_obtener_tarea_edicion,
    repo_obtener_tipos_tarea,
    repo_obtener_usuarios_activos,
    repo_actualizar_tarea,
    repo_finalizar_accion,
)
from modules.tasks import task_queries as q
from modules.tasks.task_utils import parse_dt, _extract_email, _norm_email


ESTADOS_NO_EDITABLES = ("Terminado", "Cerrado por sistema")
PREGUNTAS_ENCUESTA = [
    "¿Cómo califica la atención recibida?",
    "¿El tiempo de respuesta fue adecuado?",
    "¿La solución entregada resolvió su requerimiento?",
    "¿El técnico comunicó claramente el avance o solución?",
    "¿Qué tan satisfecho está con la gestión general del ticket?",
]


def svc_crear_y_enviar_encuesta(task_id: int):
    tarea = repo_obtener_tarea_para_encuesta(task_id)
    if not tarea:
        return False

    if not tarea.get("solicitante_id") or not tarea.get("solicitante_email"):
        return False

    existente = repo_obtener_encuesta_por_tarea(task_id)
    if existente:
        return False

    conn = get_db()
    token = secrets.token_urlsafe(32)

    try:
        encuesta_id = repo_insertar_encuesta(
            conn,
            task_id,
            tarea.get("solicitante_id"),
            token,
        )
        conn.commit()
    except Exception as e:
        conn.rollback()
        print("Error creando encuesta:", e)
        return False

    try:
        encuesta_url = url_for("responder_encuesta", token=token, _external=True)
        msg, smtp_host, smtp_port, smtp_user, smtp_pass, use_tls = _send_encuesta_satisfaccion_mail(
            tarea,
            encuesta_url,
        )

        if not msg or not smtp_host:
            return False

        msg["To"] = tarea["solicitante_email"]

        if use_tls:
            with smtplib.SMTP(smtp_host, smtp_port) as server:
                server.starttls()
                if smtp_user and smtp_pass:
                    server.login(smtp_user, smtp_pass)
                server.send_message(msg)
        else:
            with smtplib.SMTP_SSL(smtp_host, smtp_port) as server:
                if smtp_user and smtp_pass:
                    server.login(smtp_user, smtp_pass)
                server.send_message(msg)

        conn = get_db()
        repo_marcar_encuesta_enviada(conn, encuesta_id)
        conn.commit()
        return True

    except Exception as e:
        print("Error enviando encuesta:", e)
        return False


def svc_build_encuestas_context(user, request_args):
    estado = (request_args.get("estado") or "").strip()
    q = (request_args.get("q") or "").lower().strip()

    encuestas = repo_listar_encuestas()
    filtradas = []

    for row in encuestas:
        r = dict(row)

        if estado and r.get("estado") != estado:
            continue

        texto = " ".join(str(v or "") for v in r.values()).lower()
        if q and q not in texto:
            continue

        promedio = r.get("promedio")
        r["promedio_fmt"] = f"{float(promedio):.1f}" if promedio is not None else "—"
        filtradas.append(r)

    pendientes = sum(1 for x in encuestas if x.get("estado") == "Pendiente")
    realizadas = sum(1 for x in encuestas if x.get("estado") == "Realizada")

    return {
        "usuario": user["username"],
        "rol": user["rol"],
        "encuestas": filtradas,
        "estado_sel": estado,
        "q": q,
        "total": len(encuestas),
        "pendientes": pendientes,
        "realizadas": realizadas,
        "active_page": "encuestas",
    }


def svc_build_responder_encuesta_context(token: str):
    encuesta = repo_obtener_encuesta_por_token(token)
    if not encuesta:
        return {"ok": False, "message": "Encuesta no encontrada."}

    return {
        "ok": True,
        "encuesta": encuesta,
        "preguntas": PREGUNTAS_ENCUESTA,
        "active_page": "encuestas_publica",
    }


def svc_guardar_respuesta_encuesta(token: str, form):
    encuesta = repo_obtener_encuesta_por_token(token)
    if not encuesta:
        return {"ok": False, "message": "Encuesta no encontrada.", "category": "danger"}

    if encuesta["estado"] == "Realizada":
        return {"ok": False, "message": "Esta encuesta ya fue respondida.", "category": "warning"}

    comentario = (form.get("comentario") or "").strip()
    respuestas = []

    for i in range(1, 6):
        raw = (form.get(f"pregunta_{i}") or "").strip()
        try:
            value = int(raw)
        except ValueError:
            return {"ok": False, "message": "Debe responder todas las preguntas.", "category": "warning"}

        if value < 1 or value > 5:
            return {"ok": False, "message": "Las calificaciones deben estar entre 1 y 5.", "category": "warning"}

        respuestas.append((i, value))

    conn = get_db()

    try:
        for pregunta_numero, puntuacion in respuestas:
            repo_insertar_respuesta_encuesta(conn, encuesta["id"], pregunta_numero, puntuacion)

        changed = repo_finalizar_encuesta(conn, encuesta["id"], comentario)
        conn.commit()

        if not changed:
            return {"ok": False, "message": "No se pudo registrar la encuesta.", "category": "warning"}

        return {"ok": True, "message": "Gracias por responder la encuesta.", "category": "success"}

    except Exception as e:
        conn.rollback()
        return {"ok": False, "message": f"Error guardando encuesta: {str(e)}", "category": "danger"}

class TaskServiceError(Exception):
    def __init__(self, message: str, category: str = "danger"):
        super().__init__(message)
        self.message = message
        self.category = category


#def svc_build_dashboard_context(user):
def svc_build_dashboard_context(user, request_args=None):    
    tareas_raw = repo_dashboard_tareas(user)
    request_args = request_args or {}

    fecha_desde_raw = (request_args.get("fecha_desde") or "").strip()
    fecha_hasta_raw = (request_args.get("fecha_hasta") or "").strip()
    depto_sel = (request_args.get("depto") or "").strip()

    fecha_desde = parse_dt(fecha_desde_raw) if fecha_desde_raw else None
    fecha_hasta = parse_dt(fecha_hasta_raw) if fecha_hasta_raw else None

    if fecha_hasta:
        fecha_hasta = fecha_hasta.replace(hour=23, minute=59, second=59)

    tareas_filtradas = []

    for r in tareas_raw:
        t = dict(r)

        if depto_sel and (t.get("departamento") or "") != depto_sel:
            continue

        fecha_base = parse_dt(str(t.get("fecha_cierre_real") or t.get("fecha_creacion") or "").strip())

        if fecha_desde and (not fecha_base or fecha_base < fecha_desde):
            continue

        if fecha_hasta and (not fecha_base or fecha_base > fecha_hasta):
            continue

        tareas_filtradas.append(t)

    tareas_raw = tareas_filtradas

    hoy = date.today()
    week_end = hoy + timedelta(days=(6 - hoy.weekday()))

    conteos = {estado: 0 for estado in ESTADOS}

    overdue_tasks = []
    today_tasks = []
    week_tasks = []
    no_due_tasks = []

    overdue_by_user_count = defaultdict(int)
    overdue_by_depto_count = defaultdict(int)
    compromiso_counts = defaultdict(int)
    horas_cerradas_por_usuario_count = defaultdict(float)

    for r in tareas_raw:
        t = dict(r)
        estado = t["estado"]

        if estado in conteos:
            conteos[estado] += 1
        else:
            conteos[estado] = conteos.get(estado, 0) + 1

        comp_dt = parse_dt(t.get("fecha_compromiso"))

        inicio_dt = parse_dt(t.get("fecha_inicio"))
        cierre_dt = parse_dt(t.get("fecha_cierre_real"))

        if estado in ("Terminado", "Cerrado por sistema") and inicio_dt and cierre_dt:
            horas = round((cierre_dt - inicio_dt).total_seconds() / 3600, 2)
            if horas >= 0:
                owner = t.get("propietario") or "—"
                horas_cerradas_por_usuario_count[owner] += horas

        if comp_dt:
            compromiso_counts[comp_dt.date()] += 1

        t["fecha_compromiso_fmt"] = comp_dt.strftime("%Y-%m-%d %H:%M") if comp_dt else ""
        no_terminada = estado not in ("Terminado", "Cerrado por sistema")

        if comp_dt and no_terminada:
            comp_date = comp_dt.date()
            if comp_date < hoy:
                t["dias_atraso"] = (hoy - comp_date).days
                overdue_tasks.append(t)

                owner = t.get("propietario") or "—"
                depto = t.get("departamento") or "Sin departamento"
                overdue_by_user_count[owner] += 1
                overdue_by_depto_count[depto] += 1
            elif comp_date == hoy:
                t["dias_atraso"] = 0
                today_tasks.append(t)
            elif hoy < comp_date <= week_end:
                t["dias_atraso"] = 0
                week_tasks.append(t)
        elif not comp_dt and no_terminada:
            t["dias_atraso"] = None
            no_due_tasks.append(t)

    overdue_by_user = sorted(
        [{"usuario": u, "total": c} for u, c in overdue_by_user_count.items()],
        key=lambda x: -x["total"],
    )

    overdue_by_depto = sorted(
        [{"departamento": d, "total": c} for d, c in overdue_by_depto_count.items()],
        key=lambda x: -x["total"],
    )

    horas_cerradas_por_usuario = sorted(
        [
            {"usuario": u, "horas": round(h, 2)}
            for u, h in horas_cerradas_por_usuario_count.items()
        ],
        key=lambda x: -x["horas"],
    )

    dates_sorted = sorted(compromiso_counts.keys())

    return {
        "usuario": user["username"],
        "deptos": repo_obtener_departamentos_tareas(),
        "depto_sel": depto_sel,
        "fecha_desde": fecha_desde_raw,
        "fecha_hasta": fecha_hasta_raw,
        "rol": user["rol"],
        "estados": ESTADOS,
        "conteos": conteos,
        "total": len(tareas_raw),
        "overdue_tasks": overdue_tasks,
        "today_tasks": today_tasks,
        "week_tasks": week_tasks,
        "no_due_tasks": no_due_tasks,
        "overdue_by_user": overdue_by_user,
        "overdue_by_depto": overdue_by_depto,
        "horas_cerradas_por_usuario": horas_cerradas_por_usuario,
        "chart": {
            "status": {
                "labels": list(ESTADOS),
                "data": [conteos.get(e, 0) for e in ESTADOS],
            },
            "overdue_user": {
                "labels": [row["usuario"] for row in overdue_by_user],
                "data": [row["total"] for row in overdue_by_user],
            },
            "overdue_depto": {
                "labels": [row["departamento"] for row in overdue_by_depto],
                "data": [row["total"] for row in overdue_by_depto],
            },
            "timeline": {
                "labels": [d.isoformat() for d in dates_sorted],
                "data": [compromiso_counts[d] for d in dates_sorted],
            },
        },
        "active_page": "dashboard",
    }

def svc_build_listar_tareas_context(user, request_args):
    tareas_raw = repo_listar_tareas_raw()
    resp_rows = repo_listar_tarea_responsables_map()

    fecha_desde_raw = (request_args.get("fecha_desde") or "").strip()
    fecha_hasta_raw = (request_args.get("fecha_hasta") or "").strip()

    fecha_desde = parse_dt(fecha_desde_raw) if fecha_desde_raw else None
    fecha_hasta = parse_dt(fecha_hasta_raw) if fecha_hasta_raw else None

    if fecha_hasta:
        fecha_hasta = fecha_hasta.replace(hour=23, minute=59, second=59)

    responsables_map = {}
    for r in resp_rows:
        tid = r["tarea_id"]
        responsables_map.setdefault(tid, []).append(dict(r))

    for t in tareas_raw:
        resp_list = responsables_map.get(t["id"], [])
        ids = set()
        labels = []
        deptos = set()

        for r in resp_list:
            ids.add(r["usuario_id"])

            dept_name = (r["depto_nombre"] or "").strip()
            if dept_name:
                deptos.add(dept_name)

            nombre = (r["nombre_completo"] or "").strip()
            username = (r["username"] or "").strip()

            if nombre:
                labels.append(f"{nombre} ({username})")
            elif username:
                labels.append(username)

        if not ids:
            if t.get("usuario_id"):
                ids.add(t["usuario_id"])

            label_base = (t.get("creador_username") or "").strip()
            nombre_creador = (t.get("creador_nombre") or "").strip()

            if nombre_creador:
                labels.append(f"{nombre_creador} ({label_base})" if label_base else nombre_creador)
            elif label_base:
                labels.append(label_base)

        t["responsable_ids"] = ids
        t["propietario"] = ", ".join(labels) if labels else "Sin asignar"
        t["departamentos_responsables"] = ", ".join(sorted(deptos)) if deptos else "N/A"

    vista = (request_args.get("vista") or "realizar").lower()
    if vista not in ("realizar", "mis"):
        vista = "realizar"

    tareas_filtradas = []

    for t in tareas_raw:
        fecha_base = parse_dt(
            str(
                t.get("fecha_cierre_real")
                or t.get("fecha_fin")
                or t.get("fecha_inicio")
                or t.get("fecha_creacion")
                or ""
            ).strip()
        )

        if fecha_desde and (not fecha_base or fecha_base < fecha_desde):
            continue

        if fecha_hasta and (not fecha_base or fecha_base > fecha_hasta):
            continue

        if user["rol"] in ("admin", "jefe"):
            pasa_rol = True
        else:
            pasa_rol = (user["id"] in t["responsable_ids"]) or (t["creador_id"] == user["id"])

        if not pasa_rol:
            continue

        if vista == "realizar":
            if user["rol"] not in ("admin", "jefe") and user["id"] not in t["responsable_ids"]:
                continue
        else:
            if user["rol"] not in ("admin", "jefe") and t["creador_id"] != user["id"]:
                continue

        tareas_filtradas.append(t)

    try:
        edit_minutes_conf = float(get_config_value("edit_minutes", "5"))
    except Exception:
        edit_minutes_conf = 5.0

    tareas_list = []

    for t in tareas_filtradas:
        editable = False

        if user["rol"] == "admin":
            editable = True
        else:
            if user["id"] in t["responsable_ids"] and t["estado"] not in ESTADOS_NO_EDITABLES:
                editable = True

        t["editable"] = editable
        tareas_list.append(t)

    return {
        "tareas": tareas_list,
        "usuario": user["username"],
        "rol": user["rol"],
        "user_id": user["id"],
        "active_page": "tareas",
        "edit_minutes": edit_minutes_conf,
        "vista": vista,
        "fecha_desde": fecha_desde_raw,
        "fecha_hasta": fecha_hasta_raw,
    }




def svc_build_nueva_tarea_context(user, modo: str):
    if modo not in ("para_mi", "asignar"):
        modo = "asignar"

    return {
        "usuario": user["username"],
        "empresas": repo_obtener_empresas_activas(),
        "user_id": user["id"],
        "rol": user["rol"],
        "responsables": repo_obtener_responsables(user, modo),
        "solicitantes": repo_obtener_solicitantes(),
        "tipos_tarea": repo_obtener_tipos_tarea(),
        "modo": modo,
        "modo_asignar": (modo == "asignar"),
        "active_page": "tareas",
    }


def _parse_task_form_dates(fecha_inicio_raw, fecha_comp_raw, fecha_fin_raw):
    fi = fc = ff = None
    try:
        if fecha_inicio_raw:
            fi = datetime.strptime(fecha_inicio_raw, "%Y-%m-%dT%H:%M")
        if fecha_comp_raw:
            fc = datetime.strptime(fecha_comp_raw, "%Y-%m-%dT%H:%M")
        if fecha_fin_raw:
            ff = datetime.strptime(fecha_fin_raw, "%Y-%m-%dT%H:%M")
    except ValueError:
        raise TaskServiceError("Formato de fecha inválido.", "danger")

    if fi and fc and fc < fi:
        raise TaskServiceError(
            "La fecha compromiso no puede ser anterior a la de inicio.",
            "warning",
        )

    return fi, fc, ff


def svc_crear_tarea(user, form):
    modo = (form.get("modo") or "asignar").lower()
    if modo not in ("para_mi", "asignar"):
        modo = "asignar"

    titulo = (form.get("titulo") or "").strip()
    descripcion = (form.get("descripcion") or "").strip()
    tipo_tarea_id = form.get("tipo_tarea_id")
    empresa_id = form.get("empresa_id")

    fi, fc, ff = _parse_task_form_dates(
        (form.get("fecha_inicio") or "").strip(),
        (form.get("fecha_compromiso") or "").strip(),
        (form.get("fecha_fin") or "").strip(),
    )

    now = datetime.now()
    estado = "Por iniciar" if not fi and not fc else ("Atrasada" if fc and fc < now else "En desarrollo")

    fi_str = fi.strftime("%Y-%m-%d %H:%M:%S") if fi else None
    fc_str = fc.strftime("%Y-%m-%d %H:%M:%S") if fc else None
    ff_str = ff.strftime("%Y-%m-%d %H:%M:%S") if ff else None

    solicitante_raw = form.get("solicitante_id")
    solicitante_id = int(solicitante_raw) if solicitante_raw else int(user["id"])

    responsables_raw = form.getlist("responsable_ids")
    if modo == "asignar":
        responsable_ids = [int(r) for r in responsables_raw if str(r).strip()]
        if not responsable_ids:
            responsable_ids = [int(user["id"])]
    else:
        responsable_ids = [int(user["id"])]

    responsable_ids = list(dict.fromkeys(responsable_ids))

    conn = get_db()

    try:
        responsable_principal = responsable_ids[0]
        tarea_id = repo_insertar_tarea(
            conn,
            {
                "titulo": titulo,
                "descripcion": descripcion,
                "estado": estado,
                "fecha_creacion": now.strftime("%Y-%m-%d %H:%M:%S"),
                "fecha_inicio": fi_str,
                "fecha_compromiso": fc_str,
                "fecha_fin": ff_str,
                "usuario_id": responsable_principal,
                "creador_id": user["id"],
                "solicitante_id": solicitante_id,
                "tipo_tarea_id": tipo_tarea_id,
                "empresa_id": empresa_id,
            },
        )

        for rid in responsable_ids:
            repo_insertar_tarea_responsable_si_no_existe(conn, tarea_id, rid)

        conn.commit()
        return {
            "ok": True,
            "message": f"Tarea {tarea_id:07d} creada correctamente.",
            "category": "success",
            "redirect_endpoint": "listar_tareas",
            "redirect_kwargs": {"vista": "realizar"},
        }
    except Exception as e:
        conn.rollback()
        return {
            "ok": False,
            "message": f"Error al guardar la tarea: {str(e)}",
            "category": "danger",
            "redirect_endpoint": "nueva_tarea",
            "redirect_kwargs": {"modo": modo},
        }


def svc_obtener_tarea_para_ver(user, task_id: int):
    tarea = repo_obtener_tarea_detalle(task_id)
    if not tarea:
        return {
            "ok": False,
            "message": "Tarea no encontrada.",
            "category": "warning",
            "redirect_endpoint": "listar_tareas",
            "redirect_kwargs": {},
        }

    if user["rol"] != "admin":
        if tarea["usuario_id"] != user["id"] and tarea["creador_id"] != user["id"]:
            return {
                "ok": False,
                "message": "No tiene permiso para ver esta tarea.",
                "category": "danger",
                "redirect_endpoint": "listar_tareas",
                "redirect_kwargs": {},
            }

    return {
        "ok": True,
        "tarea": tarea,
        "acciones": repo_obtener_tarea_acciones(task_id),
        "puede_anotar": (
            user["rol"] == "admin"
            or tarea["usuario_id"] == user["id"]
            or tarea["creador_id"] == user["id"]
        ),
        "responsables": repo_obtener_usuarios_activos(),
        "usuario": user["username"],
        "rol": user["rol"],
        "active_page": "tareas",
    }


def _enviar_correo_avance_si_aplica(tarea, observacion, detalles, now_str, actor_username, usuario_accion_id):
    try:
        email_asignado_observacion = None
        if usuario_accion_id:
            u_obs = repo_obtener_email_usuario(int(usuario_accion_id))
            if u_obs:
                email_asignado_observacion = u_obs["email"]

        resp_rows = repo_obtener_emails_responsables_tarea(tarea["id"])

        if not resp_rows:
            row_fallback = repo_obtener_email_usuario(tarea["usuario_id"])
            if row_fallback:
                resp_rows = [row_fallback]

        destinatarios_set = {r["email"] for r in resp_rows if r and r["email"]}

        if tarea["solicitante_id"]:
            sol_row = repo_obtener_email_usuario(tarea["solicitante_id"])
            if sol_row and sol_row["email"]:
                destinatarios_set.add(sol_row["email"])

        if email_asignado_observacion:
            destinatarios_set.add(email_asignado_observacion)

        destinatarios = list(destinatarios_set)
        if not destinatarios:
            return

        msg, smtp_host, smtp_port, smtp_user, smtp_pass, use_tls = _send_tarea_avance_mail(
            tarea,
            observacion,
            detalles,
            now_str,
            actor_username=actor_username,
        )

        if not msg or not smtp_host:
            return

        msg["To"] = ", ".join(destinatarios)

        if use_tls:
            with smtplib.SMTP(smtp_host, smtp_port) as server:
                server.starttls()
                if smtp_user and smtp_pass:
                    server.login(smtp_user, smtp_pass)
                server.send_message(msg)
        else:
            with smtplib.SMTP_SSL(smtp_host, smtp_port) as server:
                if smtp_user and smtp_pass:
                    server.login(smtp_user, smtp_pass)
                server.send_message(msg)
    except Exception as e:
        print("Error enviando correo de avance:", e)

 
def svc_registrar_accion_tarea(user, task_id: int, form):
    tarea = repo_obtener_tarea_detalle(task_id)
    if not tarea:
        return {
            "ok": False,
            "message": "Tarea no encontrada.",
            "category": "warning",
        }

    observacion = (form.get("observacion") or "").strip()
    detalles = (form.get("detalles") or "").strip()
    estado_accion = (form.get("estado_accion") or "").strip() or None

    fecha_fin_tentativa_raw = (form.get("fecha_fin_tentativa") or "").strip()
    if fecha_fin_tentativa_raw:
        try:
            fecha_fin_tentativa_dt = datetime.strptime(fecha_fin_tentativa_raw, "%Y-%m-%dT%H:%M")
            fecha_fin_tentativa = fecha_fin_tentativa_dt.strftime("%Y-%m-%d %H:%M:%S")
        except ValueError:
            return {
                "ok": False,
                "message": "La fecha fin tentativa tiene un formato inválido.",
                "category": "warning",
            }
    else:
        fecha_fin_tentativa = None

    usuario_accion_raw = (form.get("usuario_accion_id") or "").strip()
    usuario_accion_id = int(usuario_accion_raw) if usuario_accion_raw else None

    if not observacion and not detalles:
        return {
            "ok": False,
            "message": "Escribe al menos una observación o detalle para registrar la acción.",
            "category": "warning",
        }

    now = datetime.now()
    now_str = now.strftime("%Y-%m-%d %H:%M:%S")
    conn = get_db()

    try:
        repo_insertar_tarea_accion(
            conn,
            {
                "tarea_id": task_id,
                "usuario_id": user["id"],
                "fecha_accion": now_str,
                "observacion": observacion,
                "detalles": detalles,
                "estado_accion": estado_accion,
                "usuario_asignado_id": usuario_accion_id,
                "fecha_fin_tentativa": fecha_fin_tentativa,
                "fecha_inicio": now_str,
            },
        )
        conn.commit()
    except Exception as e:
        conn.rollback()
        return {
            "ok": False,
            "message": f"Error al registrar la acción: {str(e)}",
            "category": "danger",
        }

    _enviar_correo_avance_si_aplica(
        tarea,
        observacion,
        detalles,
        now_str,
        actor_username=user["username"],
        usuario_accion_id=usuario_accion_id,
    )

    return {
        "ok": True,
        "message": "Acción registrada en la tarea.",
        "category": "success",
    }

def svc_reenviar_observacion(accion_id: int, actor_username: str):
    accion = repo_obtener_accion_con_tarea(accion_id)
    if not accion:
        return {
            "ok": False,
            "message": "Acción no encontrada.",
            "category": "danger",
            "redirect_endpoint": None,
            "redirect_kwargs": {},
        }

    try:
        destinatarios_set = set()
        ids_interesados = [
            accion["resp_tarea_id"],
            accion["solicitante_id"],
            accion["creador_id"],
            accion["usuario_asignado_id"],
        ]

        for uid in ids_interesados:
            if uid:
                res = repo_obtener_email_usuario(uid)
                if res and res["email"]:
                    destinatarios_set.add(res["email"])

        if destinatarios_set:
            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            msg, smtp_host, smtp_port, smtp_user, smtp_pass, use_tls = _send_tarea_avance_mail(
                accion,
                f"(RECORDATORIO) {accion['observacion']}",
                accion["detalles"] or "",
                now_str,
                actor_username=actor_username,
            )

            if msg and smtp_host:
                del msg["Subject"]
                msg["Subject"] = f"RECORDATORIO: {accion['titulo']}"
                msg["To"] = ", ".join(destinatarios_set)

                if use_tls:
                    with smtplib.SMTP(smtp_host, smtp_port) as server:
                        server.starttls()
                        if smtp_user and smtp_pass:
                            server.login(smtp_user, smtp_pass)
                        server.send_message(msg)
                else:
                    with smtplib.SMTP_SSL(smtp_host, smtp_port) as server:
                        if smtp_user and smtp_pass:
                            server.login(smtp_user, smtp_pass)
                        server.send_message(msg)

                return {
                    "ok": True,
                    "message": f"Recordatorio enviado a: {len(destinatarios_set)} personas.",
                    "category": "success",
                    "redirect_endpoint": "ver_tarea",
                    "redirect_kwargs": {"task_id": accion["tarea_id"]},
                }

        return {
            "ok": False,
            "message": "No hay correos electrónicos válidos para notificar.",
            "category": "warning",
            "redirect_endpoint": "ver_tarea",
            "redirect_kwargs": {"task_id": accion["tarea_id"]},
        }
    except Exception as e:
        print(f"Error reenviando correo: {e}")
        return {
            "ok": False,
            "message": f"Error al enviar: {str(e)}",
            "category": "danger",
            "redirect_endpoint": "ver_tarea",
            "redirect_kwargs": {"task_id": accion["tarea_id"]},
        }


def svc_finalizar_accion(accion_id: int):
    accion = repo_obtener_accion_con_tarea(accion_id)
    if not accion:
        return {
            "ok": False,
            "message": "No se pudo encontrar la acción.",
            "category": "danger",
            "redirect_endpoint": "listar_tareas",
            "redirect_kwargs": {},
        }

    conn = get_db()
    rowcount = repo_finalizar_accion(conn, accion_id)
    conn.commit()

    if rowcount:
        return {
            "ok": True,
            "message": "Estado de la acción actualizado a Finalizado.",
            "category": "success",
            "redirect_endpoint": "ver_tarea",
            "redirect_kwargs": {"task_id": accion["tarea_id"]},
        }

    return {
        "ok": False,
        "message": "No se pudo encontrar la acción.",
        "category": "danger",
        "redirect_endpoint": "listar_tareas",
        "redirect_kwargs": {},
    }


def svc_obtener_tarea_para_editar(user, task_id: int):
    tarea = repo_obtener_tarea_edicion(task_id)
    if not tarea:
        return {
            "ok": False,
            "message": "Tarea no encontrada.",
            "category": "warning",
            "redirect_endpoint": "listar_tareas",
            "redirect_kwargs": {},
        }

    if user["rol"] != "admin" and tarea["estado"] == "Cerrado por sistema":
        return {
            "ok": False,
            "message": "No se puede editar una tarea cerrada por el sistema.",
            "category": "warning",
            "redirect_endpoint": "listar_tareas",
            "redirect_kwargs": {},
        }

    es_responsable = repo_es_responsable_tarea(task_id, user["id"])
    editable = (user["rol"] == "admin") or (es_responsable and tarea["estado"] not in ESTADOS_NO_EDITABLES)

    if not editable:
        return {
            "ok": False,
            "message": "No tiene permiso para editar esta tarea.",
            "category": "danger",
            "redirect_endpoint": "listar_tareas",
            "redirect_kwargs": {},
        }

    return {
        "ok": True,
        "tarea": tarea,
        "empresas": repo_obtener_empresas_activas(),
        "estados": ESTADOS,
        "usuario": user["username"],
        "rol": user["rol"],
        "is_admin": (user["rol"] == "admin"),
        "solicitantes": repo_obtener_solicitantes(),
        "tipos_tarea": repo_obtener_tipos_tarea(),
        "active_page": "tareas",
    }


def svc_guardar_edicion_tarea(user, task_id: int, form):
    tarea = repo_obtener_tarea_edicion(task_id)
    if not tarea:
        return {
            "ok": False,
            "message": "Tarea no encontrada.",
            "category": "warning",
            "redirect_endpoint": "listar_tareas",
            "redirect_kwargs": {},
        }

    es_responsable = repo_es_responsable_tarea(task_id, user["id"])
    editable = (user["rol"] == "admin") or (es_responsable and tarea["estado"] not in ESTADOS_NO_EDITABLES)
    if not editable:
        return {
            "ok": False,
            "message": "No tiene permiso para editar esta tarea.",
            "category": "danger",
            "redirect_endpoint": "listar_tareas",
            "redirect_kwargs": {},
        }

    ahora = datetime.now()
    titulo = (form.get("titulo") or "").strip()
    descripcion = (form.get("descripcion") or "").strip()
    estado = (form.get("estado", tarea["estado"]) or tarea["estado"]).strip()
    avance = form.get("porcentaje_avance", 0)
    empresa_id = form.get("empresa_id")

    solicitante_raw = (form.get("solicitante_id") or "").strip()
    try:
        solicitante_id = int(solicitante_raw) if solicitante_raw else tarea.get("solicitante_id")
    except ValueError:
        solicitante_id = tarea.get("solicitante_id")

    tipo_tarea_raw = (form.get("tipo_tarea_id") or "").strip()
    try:
        tipo_tarea_id = int(tipo_tarea_raw) if tipo_tarea_raw else tarea.get("tipo_tarea_id")
    except ValueError:
        tipo_tarea_id = tarea.get("tipo_tarea_id")

    fi_raw = (form.get("fecha_inicio") or "").strip()
    fc_raw = (form.get("fecha_compromiso") or "").strip()
    ff_raw = (form.get("fecha_fin") or "").strip()
    fcr_raw = (form.get("fecha_cierre_real") or "").strip()

    try:
        dt_fi = datetime.strptime(fi_raw, "%Y-%m-%dT%H:%M") if fi_raw else None
        dt_fc = datetime.strptime(fc_raw, "%Y-%m-%dT%H:%M") if fc_raw else None
        dt_ff = datetime.strptime(ff_raw, "%Y-%m-%dT%H:%M") if ff_raw else None
        dcr_ff = datetime.strptime(fcr_raw, "%Y-%m-%dT%H:%M") if fcr_raw else None

        fi_str = dt_fi.strftime("%Y-%m-%d %H:%M:%S") if dt_fi else None
        fc_str = dt_fc.strftime("%Y-%m-%d %H:%M:%S") if dt_fc else None
        ff_str = dt_ff.strftime("%Y-%m-%d %H:%M:%S") if dt_ff else None
        _ = dcr_ff.strftime("%Y-%m-%d %H:%M:%S") if dcr_ff else None

        if dt_ff and dt_ff < ahora:
            estado = "Terminado"
    except ValueError:
        return {
            "ok": False,
            "message": "Formato de fecha inválido.",
            "category": "danger",
            "redirect_endpoint": "editar_tarea",
            "redirect_kwargs": {"task_id": task_id},
        }

    fecha_cierre_real_str = tarea.get("fecha_cierre_real")
    if estado == "Terminado":
        if not fecha_cierre_real_str:
            fecha_cierre_real_str = ahora.strftime("%Y-%m-%d %H:%M:%S")
    else:
        fecha_cierre_real_str = None

    conn = get_db()
    estado_anterior = tarea["estado"]
    repo_actualizar_tarea(
        conn,
        task_id,
        {
            "titulo": titulo,
            "descripcion": descripcion,
            "empresa_id": empresa_id,
            "estado": estado,
            "fecha_inicio": fi_str,
            "fecha_compromiso": fc_str,
            "fecha_fin": ff_str,
            "fecha_cierre_real": fecha_cierre_real_str,
            "solicitante_id": solicitante_id,
            "porcentaje_avance": avance,
            "tipo_tarea_id": tipo_tarea_id,
        },
    )
    conn.commit()
    if estado_anterior != "Terminado" and estado == "Terminado":
        svc_crear_y_enviar_encuesta(task_id)

    return {
        "ok": True,
        "message": "Tarea actualizada correctamente.",
        "category": "success",
        "redirect_endpoint": "listar_tareas",
        "redirect_kwargs": {},
    }


def svc_eliminar_tarea(user, task_id: int):
    conn = get_db()
    changes = repo_eliminar_tarea(conn, task_id, user)
    conn.commit()

    if changes:
        return {"ok": True, "message": "Tarea eliminada.", "category": "success"}
    return {
        "ok": False,
        "message": "No se pudo eliminar (permiso o inexistente).",
        "category": "warning",
    }





def svc_require_api_key(req):
    expected = (get_config_value("api_inbound_key", "") or "").strip()
    got = (req.headers.get("X-API-Key") or "").strip()
    if not expected:
        return False, "Falta configurar api_inbound_key en tabla configuracion."
    if got != expected:
        return False, "API key inválida."
    return True, ""

def svc_exportar_tareas_excel(request_args):
    texto_q = (request_args.get("q") or "").lower().strip()
    estado_f = (request_args.get("estado") or "").strip()
    prop_f = (
        request_args.get("prop")
        or request_args.get("usuario")
        or request_args.get("creador")
        or ""
    ).lower().strip()
    depto_f = (request_args.get("depto") or "").lower().strip()

    fecha_desde_raw = (request_args.get("fecha_desde") or "").strip()
    fecha_hasta_raw = (request_args.get("fecha_hasta") or "").strip()

    fecha_desde = parse_dt(fecha_desde_raw) if fecha_desde_raw else None
    fecha_hasta = parse_dt(fecha_hasta_raw) if fecha_hasta_raw else None

    if fecha_hasta:
        fecha_hasta = fecha_hasta.replace(hour=23, minute=59, second=59)

    tareas_raw = repo_listar_tareas_raw()
    resp_rows = repo_listar_tarea_responsables_map()

    responsables_map = {}
    for r in resp_rows:
        tid = r["tarea_id"]
        responsables_map.setdefault(tid, []).append(dict(r))

    filas = []

    for t in tareas_raw:
        resp_list = responsables_map.get(t["id"], [])

        responsables = []
        departamentos = set()

        for r in resp_list:
            nombre = (r.get("nombre_completo") or "").strip()
            username = (r.get("username") or "").strip()
            depto = (r.get("depto_nombre") or "").strip()

            if nombre and username:
                responsables.append(f"{nombre} ({username})")
            elif nombre:
                responsables.append(nombre)
            elif username:
                responsables.append(username)

            if depto:
                departamentos.add(depto)

        if not responsables:
            responsables.append(t.get("creador_username") or "")

        responsable_txt = ", ".join(responsables)
        depto_txt = ", ".join(sorted(departamentos)) if departamentos else (t.get("departamento_nombre") or "N/A")

        solicitante_txt = (
            f"{t.get('solicitante_nombre')} ({t.get('solicitante_username')})"
            if t.get("solicitante_nombre")
            else (t.get("solicitante_username") or "")
        )

        creado_por_txt = t.get("creador_nombre") or t.get("creador_username") or ""

        fecha_base = parse_dt(
            str(
                t.get("fecha_cierre_real")
                or t.get("fecha_fin")
                or t.get("fecha_inicio")
                or t.get("fecha_creacion")
                or ""
            ).strip()
        )

        if fecha_desde and (not fecha_base or fecha_base < fecha_desde):
            continue

        if fecha_hasta and (not fecha_base or fecha_base > fecha_hasta):
            continue

        inicio_dt = parse_dt(t.get("fecha_inicio") or t.get("fecha_creacion"))
        fin_real_dt = parse_dt(t.get("fecha_cierre_real"))

        horas_soporte = ""
        if inicio_dt and fin_real_dt:
            horas = round((fin_real_dt - inicio_dt).total_seconds() / 3600, 2)
            horas_soporte = horas if horas >= 0 else ""

        fila = {
            "Código Tarea": f"{int(t['id']):08d}",
            "Título": t.get("titulo") or "",
            "Descripción Tarea": t.get("descripcion") or "",
            "Estado Global": t.get("estado") or "",
            "Tipo Tarea": t.get("tipo_tarea_nombre") or "",
            "Creado por": creado_por_txt,
            "Solicitante": solicitante_txt,
            "F. Creación": t.get("fecha_creacion") or "",
            "Inicio": t.get("fecha_inicio") or "",
            "Fecha Compromiso": t.get("fecha_compromiso") or "",
            "Fin": t.get("fecha_fin") or "",
            "Fecha Fin Real": t.get("fecha_cierre_real") or "",
            "Horas de Soporte": horas_soporte,
            "Responsable Tarea": responsable_txt,
            "Departamento": depto_txt,
            "Empresa": t.get("empresa_nombre") or "Interno",
            "% Avance": t.get("porcentaje_avance") or 0,
        }

        usuario_texto = " ".join([
            responsable_txt,
            creado_por_txt,
            solicitante_txt,
            t.get("creador_username") or "",
            t.get("creador_nombre") or "",
            t.get("solicitante_username") or "",
            t.get("solicitante_nombre") or "",
        ]).lower()

        row_text = " ".join(str(v).lower() for v in fila.values())

        if texto_q and texto_q not in row_text:
            continue

        if estado_f and fila["Estado Global"] != estado_f:
            continue

        if prop_f and prop_f not in usuario_texto:
            continue

        if depto_f and depto_f not in fila["Departamento"].lower():
            continue

        filas.append(fila)

    df = pd.DataFrame(filas)

    output = io.BytesIO()

    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Reporte Tareas", startrow=6)

        ws = writer.sheets["Reporte Tareas"]

        label_font = Font(bold=True, size=11)
        value_font = Font(bold=False, size=11)

        ws["A1"] = "Nombre de reporte:"
        ws["B1"] = "Reporte de Tareas Detallado"
        ws["A2"] = "Fecha de generación:"
        ws["B2"] = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        ws["A3"] = "Usuario de generación:"
        ws["B3"] = session.get("nombre_completo", session.get("username", "Sistema"))

        ws["A1"].font = label_font
        ws["A2"].font = label_font
        ws["A3"].font = label_font
        ws["B1"].font = value_font
        ws["B2"].font = value_font
        ws["B3"].font = value_font

        for column_cells in ws.columns:
            values = [str(cell.value or "") for cell in column_cells]
            length = max(len(v) for v in values)
            ws.column_dimensions[column_cells[0].column_letter].width = min(length + 2, 60)

    output.seek(0)
    return output
def svc_api_inbound_email_create_task(payload):
    subject = (payload.get("subject") or "").strip()
    body = (payload.get("body") or payload.get("text") or payload.get("body_text") or "").strip()
    from_email = _extract_email(payload.get("from") or payload.get("from_email"))

    if not subject:
        return {"ok": False, "error": "Falta subject", "status": 400}
    if not from_email:
        return {"ok": False, "error": "Falta from (remitente)", "status": 400}
    if not body:
        body = "(sin cuerpo)"

    default_email = "jchavez@quimpac.com.ec"

    conn = get_db()
    cur = conn.cursor()

    uid_from = repo_find_user_id_by_email(cur, from_email)

    if uid_from:
        responsable_principal = uid_from
        solicitante_id = uid_from
    else:
        uid_def = repo_find_user_id_by_email(cur, _norm_email(default_email))
        if not uid_def:
            return {
                "ok": False,
                "error": f"Remitente {from_email} no existe y el default {default_email} no está en usuarios.",
                "status": 400,
            }

        responsable_principal = uid_def
        solicitante_id = None

    creador_id = uid_from or responsable_principal
    now = datetime.now()

    try:
        tarea_id = repo_insertar_tarea(
            conn,
            {
                "titulo": subject[:250],
                "descripcion": body,
                "estado": "Por iniciar",
                "fecha_creacion": now.strftime("%Y-%m-%d %H:%M:%S"),
                "fecha_inicio": None,
                "fecha_compromiso": None,
                "fecha_fin": None,
                "usuario_id": responsable_principal,
                "creador_id": creador_id,
                "solicitante_id": solicitante_id,
                "tipo_tarea_id": None,
                "empresa_id": None,
            },
        )
        repo_insertar_tarea_responsable_si_no_existe(conn, tarea_id, responsable_principal)
        conn.commit()
    except Exception as e:
        conn.rollback()
        return {"ok": False, "error": str(e), "status": 500}

    return {
        "ok": True,
        "tarea_id": tarea_id,
        "codigo_tarea": f"{tarea_id:07d}",
        "asignado_a_user_id": responsable_principal,
        "from_email": from_email,
        "from_encontrado": bool(uid_from),
        "default_email": default_email,
        "status": 201,
    }
